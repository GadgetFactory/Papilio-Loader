#!/bin/sh
rm -rf /opt/GadgetFactory
rm -f /usr/local/bin/papilio-loader-gui
rm -f /usr/local/bin/papilio-prog
