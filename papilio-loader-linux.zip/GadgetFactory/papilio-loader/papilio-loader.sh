#!/bin/sh
#sudo java -classpath bin net.gadgetfactory.papilio.loader.PapilioLoader
#cd /opt/GadgetFactory/papilio-loader/
sudo java -jar /opt/GadgetFactory/papilio-loader/papilio-loader.jar $1 $2 $3 $4 $5 $6
