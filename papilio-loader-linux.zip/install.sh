#!/bin/sh
#apt-get install -y default-jdk
#apt-get install -y libftdi-dev
cp -r ./GadgetFactory /opt/
ln -sf /opt/GadgetFactory/papilio-loader/papilio-loader.sh /usr/local/bin/papilio-loader-gui
ln -sf /opt/GadgetFactory/papilio-loader/programmer/linux/papilio-prog /usr/local/bin/papilio-prog
